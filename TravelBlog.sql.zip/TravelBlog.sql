-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Oct 12, 2017 at 01:58 AM
-- Server version: 5.6.35
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `TravelBlog`
--

-- --------------------------------------------------------

--
-- Table structure for table `Experiences`
--

CREATE TABLE `Experiences` (
  `ExperienceId` int(11) NOT NULL,
  `Description` longtext,
  `LocationId` int(11) NOT NULL,
  `PostDate` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Experiences`
--

INSERT INTO `Experiences` (`ExperienceId`, `Description`, `LocationId`, `PostDate`) VALUES
(5, 'Watching Taj Mahal', 4, '0001-01-01 00:00:00.000000'),
(7, 'Winery Tour', 5, '2017-10-01 00:00:00.000000'),
(8, 'Space Needle Tour', 3, '0001-01-01 00:00:00.000000'),
(9, 'Kite flying Tournament', 5, '0001-01-01 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `Locations`
--

CREATE TABLE `Locations` (
  `LocationId` int(11) NOT NULL,
  `Name` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Locations`
--

INSERT INTO `Locations` (`LocationId`, `Name`) VALUES
(3, 'Seattle'),
(4, 'India'),
(5, 'Amsterdam');

-- --------------------------------------------------------

--
-- Table structure for table `Peoples`
--

CREATE TABLE `Peoples` (
  `PeopleId` int(11) NOT NULL,
  `ExperienceId` int(11) DEFAULT NULL,
  `LocationId` int(11) DEFAULT NULL,
  `Name` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Peoples`
--

INSERT INTO `Peoples` (`PeopleId`, `ExperienceId`, `LocationId`, `Name`) VALUES
(3, 5, 3, 'Ina'),
(4, 5, 3, 'Cheeky'),
(5, 5, 3, 'Baba'),
(9, 7, 5, 'Bunny'),
(10, 7, 5, 'Ira'),
(11, 7, 5, 'Reya'),
(12, 7, 5, 'Vishu');

-- --------------------------------------------------------

--
-- Table structure for table `__EFMigrationsHistory`
--

CREATE TABLE `__EFMigrationsHistory` (
  `MigrationId` varchar(95) NOT NULL,
  `ProductVersion` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `__EFMigrationsHistory`
--

INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`) VALUES
('20171010235516_Initial', '1.1.2'),
('20171011182703_Initial.Designer', '1.1.2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Experiences`
--
ALTER TABLE `Experiences`
  ADD PRIMARY KEY (`ExperienceId`),
  ADD KEY `IX_Experiences_LocationId` (`LocationId`);

--
-- Indexes for table `Locations`
--
ALTER TABLE `Locations`
  ADD PRIMARY KEY (`LocationId`);

--
-- Indexes for table `Peoples`
--
ALTER TABLE `Peoples`
  ADD PRIMARY KEY (`PeopleId`),
  ADD KEY `IX_Peoples_ExperienceId` (`ExperienceId`),
  ADD KEY `IX_Peoples_LocationId` (`LocationId`);

--
-- Indexes for table `__EFMigrationsHistory`
--
ALTER TABLE `__EFMigrationsHistory`
  ADD PRIMARY KEY (`MigrationId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Experiences`
--
ALTER TABLE `Experiences`
  MODIFY `ExperienceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `Locations`
--
ALTER TABLE `Locations`
  MODIFY `LocationId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Peoples`
--
ALTER TABLE `Peoples`
  MODIFY `PeopleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Experiences`
--
ALTER TABLE `Experiences`
  ADD CONSTRAINT `FK_Experiences_Locations_LocationId` FOREIGN KEY (`LocationId`) REFERENCES `Locations` (`LocationId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Peoples`
--
ALTER TABLE `Peoples`
  ADD CONSTRAINT `FK_Peoples_Experiences_ExperienceId` FOREIGN KEY (`ExperienceId`) REFERENCES `Experiences` (`ExperienceId`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_Peoples_Locations_LocationId` FOREIGN KEY (`LocationId`) REFERENCES `Locations` (`LocationId`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
